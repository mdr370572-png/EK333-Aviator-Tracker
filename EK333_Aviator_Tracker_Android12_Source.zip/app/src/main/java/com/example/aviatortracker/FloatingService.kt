package com.example.aviatortracker

import android.app.Service
import android.content.*
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var label: TextView
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            label.text = "সর্বশেষ শনাক্ত: " + (intent?.getStringExtra("value") ?: "—")
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        label = TextView(this).apply {
            text = "Aviator Tracker\nOCR অপেক্ষমাণ…"
            textSize = 14f; setPadding(20, 16, 20, 16)
            setBackgroundColor(0xEE17212B.toInt()); setTextColor(0xFFFFFFFF.toInt())
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 120 }
        wm.addView(label, params)
        registerReceiver(receiver, IntentFilter("com.example.aviatortracker.NEW_RESULT"))
    }
    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        if (::label.isInitialized) wm.removeView(label)
        super.onDestroy()
    }
}
