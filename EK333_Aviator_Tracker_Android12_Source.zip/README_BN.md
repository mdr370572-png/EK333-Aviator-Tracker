# EK333 Aviator Live Tracker — Android 12 starter project

এটি Android 12 (API 31) ফোনের জন্য একটি **starter source project**, তৈরি APK নয়।

## কী আছে
- Android MediaProjection দিয়ে ব্যবহারকারীর অনুমতিতে স্ক্রিন capture
- Google ML Kit Text Recognition দিয়ে দৃশ্যমান `x` multiplier খোঁজা
- Android overlay permission থাকলে Floating Window
- সর্বশেষ শনাক্ত multiplier স্থানীয় SharedPreferences-এ রাখা

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি EK333-এর private API, server বা account-এ প্রবেশ করে না।
- OCR শুধু স্ক্রিনে দৃশ্যমান লেখা পড়তে পারে; ভুল পড়া, একই ফল বারবার পড়া বা রাউন্ড মিস হতে পারে।
- বর্তমান নমুনা পুরো স্ক্রিনের OCR করে এবং শেষ পাওয়া `1.23x`-ধরনের টেক্সট দেখায়। নির্ভুল ব্যবহারের আগে Aviator multiplier অঞ্চলের crop/region calibration এবং round-end detection যোগ করতে হবে।
- এটি ভবিষ্যৎ multiplier predict করে না, বাজি দেয় না এবং জেতার নিশ্চয়তা দেয় না।
- Screen capture চালু করলে Android-এর অনুমতি dialog-এ সম্মতি দিতে হবে। অ্যাপ বন্ধ করলে capture বন্ধ করুন।

## Build
1. Android Studio-তে project folder খুলুন।
2. Gradle sync করুন (JDK 17 প্রয়োজন)।
3. ফোনে USB debugging দিয়ে Run করুন অথবা Build > Build APK(s) ব্যবহার করুন।
4. APK output সাধারণত `app/build/outputs/apk/debug/app-debug.apk`।

## নিরাপত্তা
EK333 password, OTP, session cookie বা API key এই অ্যাপে দেবেন না। Screen capture অনুমতি কেবল নিজের সচেতন সম্মতিতে দিন।
